var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_aws_serverless_express = require("aws-serverless-express");
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
const import_meta = {};
import_dotenv.default.config();
const app = (0, import_express.default)();
app.use((0, import_cors.default)());
app.use(import_express.default.json());
const __filename = (0, import_url.fileURLToPath)(import_meta.url);
const __dirname = import_path.default.dirname(__filename);
import_dotenv.default.config({ path: import_path.default.resolve(__dirname, "../../.env") });
const {
  ZOHO_CLIENT_ID,
  ZOHO_CLIENT_SECRET,
  ZOHO_REDIRECT_URI,
  ZOHO_ORG_ID,
  ZOHO_REFRESH_TOKEN
} = process.env;
app.get("/oauth/url", (req2, res) => {
  const AUTH = "https://accounts.zoho.eu/oauth/v2/auth";
  const params = new URLSearchParams({
    response_type: "code",
    client_id: ZOHO_CLIENT_ID,
    redirect_uri: ZOHO_REDIRECT_URI,
    scope: "ZohoInventory.fullaccess.all",
    access_type: "offline",
    prompt: "consent"
  });
  res.redirect(`${AUTH}?${params}`);
});
app.get("/oauth/callback", async (req2, res) => {
  const { code } = req2.query;
  if (!code) return res.status(400).send("Missing code");
  try {
    const tokenRes = await fetch(
      "https://accounts.zoho.eu/oauth/v2/token?" + new URLSearchParams({
        grant_type: "authorization_code",
        client_id: ZOHO_CLIENT_ID,
        client_secret: ZOHO_CLIENT_SECRET,
        redirect_uri: ZOHO_REDIRECT_URI,
        code
      })
    );
    const data = await tokenRes.json();
    if (data.error) return res.status(400).send(data.error_description || data.error);
    const envPath = import_path.default.resolve(__dirname, "../../.env");
    import_fs.default.writeFileSync(
      envPath,
      `ZOHO_CLIENT_ID=${ZOHO_CLIENT_ID}
ZOHO_CLIENT_SECRET=${ZOHO_CLIENT_SECRET}
ZOHO_REDIRECT_URI=${ZOHO_REDIRECT_URI}
ZOHO_ORG_ID=${ZOHO_ORG_ID}
ZOHO_REFRESH_TOKEN=${data.refresh_token}
`
    );
    res.send(`<h1>Connected</h1><p>Expires in ${data.expires_in}s</p>`);
  } catch (e) {
    console.error(e);
    res.status(500).send("Token exchange failed");
  }
});
app.get("/oauth/refresh", async (req2, res) => {
  try {
    const tokenRes = await fetch(
      "https://accounts.zoho.eu/oauth/v2/token?" + new URLSearchParams({
        grant_type: "refresh_token",
        client_id: ZOHO_CLIENT_ID,
        client_secret: ZOHO_CLIENT_SECRET,
        refresh_token: ZOHO_REFRESH_TOKEN
      })
    );
    const data = await tokenRes.json();
    if (data.error) throw data;
    res.json(data);
  } catch (e) {
    console.error(e);
    res.status(500).send("Refresh failed");
  }
});
async function getZoho(endpoint, options = {}) {
  const tokenRes = await fetch(`${req.protocol}://${req.get("host")}/.netlify/functions/api/oauth/refresh`);
  const { access_token } = await tokenRes.json();
  const sep = endpoint.includes("?") ? "&" : "?";
  const url = `https://www.zohoapis.eu/inventory/v1${endpoint}${sep}organization_id=${ZOHO_ORG_ID}`;
  const apiRes = await fetch(url, {
    ...options,
    headers: { "Authorization": `Zoho-oauthtoken ${access_token}`, "Content-Type": "application/json" }
  });
  if (!apiRes.ok) throw new Error(`Zoho ${apiRes.status}`);
  return apiRes.json();
}
app.get("/items", async (req2, res) => res.json(await getZoho("/items")));
app.get("/purchaseorders", async (req2, res) => res.json(await getZoho(`/purchaseorders?status=${req2.query.status || "open"}`)));
app.post("/purchaseorders", async (req2, res) => res.json(await getZoho("/purchaseorders", { method: "POST", body: JSON.stringify(req2.body) })));
app.get("/agents", async (req2, res) => res.json(await getZoho("/settings/agents")));
app.get("/customers", async (req2, res) => res.json(await getZoho("/contacts")));
const server = (0, import_aws_serverless_express.createServer)(app);
const handler = (event, context) => (0, import_aws_serverless_express.proxy)(server, event, context);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
